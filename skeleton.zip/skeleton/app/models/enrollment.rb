class Enrollment < ActiveRecord::Base
end
